package com.dbutil;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class dbutil {

	//创建变量
	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private String DRIVER,URL,DBNAME,CHARSET,ACCOUNT,PASSWORD;
	public dbutil() {//在构造方法中

		Properties prop=new Properties();
		try {
			//prop.load(new FileInputStream("db.properties"));
			//prop.load(new FileInputStream("data/db.properties"));
			prop.load(new FileInputStream(dbutil.class.getClassLoader().getResource("db.properties").getPath()));
			DRIVER= prop.getProperty("DRIVER");
			URL= prop.getProperty("URL");
			DBNAME= prop.getProperty("DBNAME");
			CHARSET= prop.getProperty("CHARSET");
			ACCOUNT= prop.getProperty("ACCOUNT");
			PASSWORD= prop.getProperty("PASSWORD");
			//加载驱动类
			Class.forName(DRIVER);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	/**
	 * @author Administrator
	 * @name update
	 * @description 非预编译的方法进行数据的修改、增加、删除
	 * @return int
	 * @param sql
	 * @return
	 * @time 2019年2月15日 下午3:11:57
	 */
	public int update(String sql){
		//获取连接对象
		try {
			conn=DriverManager.getConnection(URL+DBNAME+CHARSET,ACCOUNT,PASSWORD);
			//获取语句对象
			stmt=conn.createStatement();
			//执行sql语句
			return  stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		return 0;

	}
	
	/**
	 * @author Administrator
	 * @name update
	 * @description 预编译的方法进行数据的增删改
	 * @return int
	 * @param sql  语句
	 * @param arr  匹配的值条件
	 * @return
	 * @time 2019年2月15日 下午3:12:42
	 */
	public int update(String sql,Object...arr){
		//获取连接对象
		try {
			conn=DriverManager.getConnection(URL+DBNAME+CHARSET,ACCOUNT,PASSWORD);
			//获取预编译语句对象
			pstmt=conn.prepareStatement(sql);
			//先进行数据的设置
			for (int i = 0; i < arr.length; i++) {
				pstmt.setObject(i+1, arr[i]);
			}
			//执行语句对象
			return pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		return 0;
	}
	
	/**
	 * @author Administrator
	 * @name query
	 * @description 非预编译的方法进行数据查询
	 * @return ResultSet
	 * @param sql
	 * @return
	 * @time 2019年2月15日 下午3:13:34
	 */
	public ResultSet query(String sql){
		try {
			conn=DriverManager.getConnection(URL+DBNAME+CHARSET,ACCOUNT,PASSWORD);
			//获取语句对象
			stmt=conn.createStatement();
			//执行sql语句
			return  stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * @author Administrator
	 * @name query
	 * @description 预编译的方法进行查询   多个条件查询
	 * @return ResultSet
	 * @param sql
	 * @param arr
	 * @return
	 * @time 2019年2月15日 下午3:13:54
	 */
	public ResultSet query(String sql,Object...arr){
		//获取连接对象

		try {
			conn=DriverManager.getConnection(URL+DBNAME+CHARSET,ACCOUNT,PASSWORD);
			//获取预编译语句对象
			pstmt=conn.prepareStatement(sql);
			System.out.println(arr.length);
			//先进行数据的设置
			for (int i = 0; i < arr.length; i++) {
				pstmt.setObject(i+1, arr[i]);
			}
			//执行语句对象
			return pstmt.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return null;
	}
	
	/**
	 * @author Administrator
	 * @name close
	 * @description 关闭所有资源的方法
	 * @return void
	 * @time 2019年2月15日 下午3:14:42
	 */
	public void close(){

		try {
			if(pstmt!=null ) pstmt.close();
			if(stmt!=null ) stmt.close();
			if(conn!=null ) conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
