package com.res.controlservlet;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.attribute.FileTime;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;


import com.res.domain.page;

import com.res.domain.*;
import com.res.biz.*;
import com.res.biz.Idbiz;
import com.res.bizimple.Dishbizimple;
import com.res.bizimple.Idbizimple;
import com.res.domain.Identity;


/**
 * Servlet implementation class contronlogin
 */
@WebServlet("/controllogin")
public class controllogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private Idbiz idbiz;
       private Dishbiz dishbiz;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public controllogin() {
        super();
       this.idbiz=new Idbizimple();
       this.dishbiz=new Dishbizimple();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String op=request.getParameter("op");
		if("entry".equals(op)){	
			fristentry(request,response);
		}else if("page".equals(op)){
			page(request,response);
		}else if("insert".equals(op)){
			try {
				insert(request,response);
			} catch (Exception e) {
		
				e.printStackTrace();
			}
		}else if("savelogin".equals(op)){
			savelogin(request,response);
		}else if("selectbyname".equals(op)){
			selectbyname(request,response);
		}else if("update".equals(op)){
			try {
				update(request,response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("select".equals(op)){
			select(request,response);
		}else if("delete".equals(op)){
			delete(request,response);
		}
		
		
		
		
	}

	private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String keyname=request.getParameter("currname");
		this.dishbiz.delete(keyname);
		request.setAttribute("mag", "数据已删除");
		request.getRequestDispatcher("/backstage/detail/foodList.jsp").forward(request, response);
		
	}

	private void select(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("keyword");
		
		Dish resu=this.dishbiz.selebyname(name);
		
		request.setAttribute("dish", resu);
		if(resu!=null){
			try {
				request.setAttribute("dish", resu);
				
				request.getRequestDispatcher("/backstage/detail/selectshow.jsp").forward(request, response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			request.setAttribute("mag", "对不起搜索不到数据");
			request.getRequestDispatcher("/backstage/detail/selectshow.jsp").forward(request, response);
		}
		
	}

	private void update(HttpServletRequest request, HttpServletResponse response) throws Exception {
		boolean flag=ServletFileUpload.isMultipartContent(request);
		if(!flag){
			request.setAttribute("mag", "您的填写有误请重新填写");
			
			try {
				request.getRequestDispatcher("/backstage/detail/updateFood.jsp").forward(request, response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		DiskFileItemFactory df=new DiskFileItemFactory();
		ServletFileUpload sf=new ServletFileUpload(df);
		List<FileItem> fileitem = sf.parseRequest(request);
		
		Dish dish=new Dish();
		
		String area=null;
		String path=null;
		String pictrue=null;
		for(FileItem f: fileitem){
			if(f.isFormField()){
				
				try {
					BeanUtils.setProperty(dish, f.getFieldName(), f.getString(request.getCharacterEncoding()));
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				String aa=UUID.randomUUID().toString()+"."+FilenameUtils.getExtension(f.getName());
				
				dish.setPictrue(aa);
				dish.setPath("/images/");
				//创建新文件
				//File f=new File(this.getServletContext()+dish.getPath());
				File fi=new File(this.getServletContext().getRealPath("/")+ dish.getPath());
				if(!fi.exists()){
					fi.mkdirs();
				}
				path=aa;
				pictrue=fi.getAbsolutePath()+aa;
				//f.write(new File(fi.getPath()+aa));
				f.write(new File(fi.getAbsolutePath()+"/"+aa));
			}			
		}
		dishbiz.update(dish);		
		request.setAttribute("mag", "您的菜单已修改成功");
		try {
			request.getRequestDispatcher("/backstage/detail/foodList.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void selectbyname(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("currname");
		System.out.println("---"+name+"---");
		Dish resu=this.dishbiz.selebyname(name);
		
		request.setAttribute("dish", resu);
		if(resu!=null){
			try {
				request.setAttribute("dish", resu);
				System.out.println(resu);
				request.getRequestDispatcher("/backstage/detail/updateFood.jsp").forward(request, response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			System.out.println("ooooo"+resu);
			request.getRequestDispatcher("/backstage/detail/updateFood.jsp").forward(request, response);
		}
		
	}

	private void savelogin(HttpServletRequest request, HttpServletResponse response) {
		List <Dish> list=this.dishbiz.selectall();
		request.setAttribute("list", list);
		try {
			request.getRequestDispatcher("/backstage/detail/saveFood.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void insert(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		
		
		
		boolean flag=ServletFileUpload.isMultipartContent(request);
		if(!flag){
			request.setAttribute("mag", "您的填写有误请重新填写");
			
			try {
				request.getRequestDispatcher("/backstage/detail/saveFood.jsp").forward(request, response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		DiskFileItemFactory df=new DiskFileItemFactory();
		ServletFileUpload sf=new ServletFileUpload(df);
		List<FileItem> fileitem = sf.parseRequest(request);
		System.out.println(fileitem.size());
		Dish dish=new Dish();
		String foodid=request.getParameter("foodid");
		//Double.valueOf(vipdish.toString());
		String foodname=request.getParameter("foodName");
		String price=request.getParameter("price123");
		String vipprice=request.getParameter("mprice");
		String area=null;
		String path=null;
		String pictrue=null;
		for(FileItem f: fileitem){
			if(f.isFormField()){
				System.out.println("0"+f.getName());
				System.out.println("1"+f.getFieldName());
				System.out.println("2"+f.getString(request.getCharacterEncoding()));
				System.out.println("--------------------");
				BeanUtils.setProperty(dish, f.getFieldName(), f.getString(request.getCharacterEncoding()));
			}else{
				String aa=UUID.randomUUID().toString()+"."+FilenameUtils.getExtension(f.getName());
				System.out.println("else:"+aa);
				dish.setPictrue(aa);
				dish.setPath("/images/");
				//创建新文件
				//File f=new File(this.getServletContext()+dish.getPath());
				File fi=new File(this.getServletContext().getRealPath("/")+ dish.getPath());
				if(!fi.exists()){
					fi.mkdirs();
				}
				path=aa;
				pictrue=fi.getAbsolutePath()+aa;
				//f.write(new File(fi.getPath()+aa));
				f.write(new File(fi.getAbsolutePath()+"/"+aa));
				System.out.println(fi.getAbsolutePath()+aa);
			}
			
		}
		dishbiz.adddish(dish);
		//response.sendRedirect("indexe.jsp");
		request.setAttribute("mag", "您的菜单已添加成功");
		try {
			request.getRequestDispatcher("/backstage/detail/saveFood.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*if(!flag){
			request.setAttribute("mag", "您的填写有误请重新填写");
			
			try {
				request.getRequestDispatcher("/backstage/detail/saveFood.jsp").forward(request, response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		DiskFileItemFactory df=new DiskFileItemFactory();
		ServletFileUpload sf=new ServletFileUpload(df);
		List<FileItem> fileitem = sf.parseRequest(request);
		System.out.println(fileitem.size());
		Dish dish=new Dish();
		String foodid=request.getParameter("foodid");
		//Double.valueOf(vipdish.toString());
		String foodname=request.getParameter("foodName");
		String price=request.getParameter("price123");
		String vipprice=request.getParameter("mprice");
		String area=null;
		String path=null;
		String pictrue=null;
		for(FileItem f: fileitem){
			if(f.isFormField()){
				System.out.println("0"+f.getName());
				System.out.println("1"+f.getFieldName());
				System.out.println("2"+f.getString(request.getCharacterEncoding()));
				System.out.println("--------------------");
				if("area".equals(f.getFieldName()) ){
					area=f.getString(request.getCharacterEncoding());
														
				}else if("dishid".equals(f.getFieldName())){
					foodid=f.getString(request.getCharacterEncoding());
				}else if("dishname".equals(f.getFieldName())){
					foodname=f.getString(request.getCharacterEncoding());
				}else if("price".equals(f.getFieldName())){
					price=f.getString(request.getCharacterEncoding());
				}else if("vipprice".equals(f.getFieldName())){
					vipprice=f.getString(request.getCharacterEncoding());
				}
				
			}else{
				String aa=UUID.randomUUID().toString()+"."+FilenameUtils.getExtension(f.getName());
				System.out.println("else:"+aa);
				dish.setPictrue(aa);
				dish.setPath("/images/");
				//创建新文件
				//File f=new File(this.getServletContext()+dish.getPath());
				File fi=new File(this.getServletContext().getRealPath("/")+ dish.getPath());
				if(!fi.exists()){
					fi.mkdirs();
				}
				path=aa;
				pictrue=fi.getAbsolutePath()+aa;
				//f.write(new File(fi.getPath()+aa));
				f.write(new File(fi.getAbsolutePath()+"/"+aa));
				System.out.println(fi.getAbsolutePath()+aa);
			}
			
		}
		dishbiz.adddish(new Dish(foodname, area,Double.valueOf(price.toString()) ,foodid,Double.valueOf(vipprice.toString()),pictrue,path ));
		//response.sendRedirect("indexe.jsp");
		request.setAttribute("mag", "您的菜单已添加成功");
		try {
			request.getRequestDispatcher("/backstage/detail/saveFood.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		*/
	}

	private void page(HttpServletRequest request, HttpServletResponse response) {
		String currpage=request.getParameter("currpage");
		page <Dish> page=this.dishbiz.selepag(currpage);
		request.setAttribute("page", page);
		try {
			request.getRequestDispatcher("/backstage/detail/foodList.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void fristentry(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		// TODO Auto-generated method stub
		String acc=request.getParameter("account");
		String pass=request.getParameter("password");
		//System.out.println(acc+"------"+pass);
		Identity result = idbiz.login(acc, pass);
		request.setAttribute("user", result);
		HttpSession se = request.getSession();
		se.setAttribute("user", result);
		//response.sendRedirect(this.getServletContext().getContextPath()+"/Are/index.jsp");
		//response.sendRedirect(this.getServletContext().getContextPath()+"/Are/index.html");
		if(result !=null){
			if(result.getPower()==0){
				response.sendRedirect(this.getServletContext().getContextPath()+"/Are/index.jsp");
				//request.getRequestDispatcher("/Are/index.jsp").forward(request, response);				
			}else{				
				//request.getRequestDispatcher("backstage/index.jsp").forward(request, response);
				response.sendRedirect(this.getServletContext().getContextPath()+"/backstage/index.jsp");
			}
		}else{
			response.sendRedirect(this.getServletContext().getContextPath()+"/Are/index.html");
		}	
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
