package com.res.bizimple;

import java.util.List;
import java.util.UUID;

import com.res.biz.Dishbiz;
import com.res.domain.page;

import com.res.dao.Dishdao;
import com.res.domain.Dish;
import com.res.daoimple.Dishdaoimple;
public class Dishbizimple implements Dishbiz {
private Dishdao dishdao;
	public Dishbizimple() {
	super();
	this.dishdao = new Dishdaoimple();
}
	@Override
	public List<Dish> selectall() {
		
		return this.dishdao.selectall();
	}
	@Override
	public page selepag(String page) {
		int nowpage=1;
		if(page!=null){
			nowpage=Integer.parseInt(page);	
		}
		page<Dish> p=new page<Dish>(nowpage,this.dishdao.getcount());
		p.setList(this.dishdao.selepaging(p.getstrat(), p.getNumber()));
		return p;
		
	}
	@Override
	public void adddish(Dish c) {
		if(c.getDishid()==""){
		c.setDishid(UUID.randomUUID().toString());}
		this.dishdao.adddish(c);
		
	}
	@Override
	public Dish selebyname(String name) {
		
		return this.dishdao.selebyid(name);
	}
	@Override
	public void update(Dish c) {
		this.dishdao.update(c);
		
	}
	@Override
	public void delete(String name) {
		this.dishdao.delete(name);
		
	}

}
