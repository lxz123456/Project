package com.res.dao;

import com.res.domain.Identity;

public interface Iddao {
	 Identity login(String acc,String pass);
}
