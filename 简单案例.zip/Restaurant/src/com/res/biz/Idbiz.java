package com.res.biz;

import com.res.domain.Identity;

public interface Idbiz {
 Identity login(String acc,String pass);
}
