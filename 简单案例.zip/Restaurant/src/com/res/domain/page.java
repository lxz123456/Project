package com.res.domain;

import java.util.List;

public class page <T>{
private int number=5;
private int nowpage;
private int totalnumber;
private List<T> list;
public page(int nowpage, int totalnumber) {
	super();
	this.nowpage = nowpage;
	this.totalnumber = totalnumber;
}
public int getNumber() {
	return number;
}
public void setNumber(int number) {
	this.number = number;
}
public int getNowpage() {
	return nowpage;
}
public void setNowpage(int nowpage) {
	this.nowpage = nowpage;
}
public int getTotalnumber() {
	return totalnumber;
}
public void setTotalnumber(int totalnumber) {
	this.totalnumber = totalnumber;
}
public List<T> getList() {
	return list;
}
public void setList(List<T> list) {
	this.list = list;
}
public int gettotal(){
	return this.totalnumber%this.number==0?this.totalnumber/this.number:this.totalnumber/this.number+1;
	
}
public int getprevpage(){
	
	return this.nowpage-1>0?this.nowpage-1:1;
}
public int nextpage(){
	System.out.println(this.totalnumber);
	return this.nowpage+1>this.getTotalnumber()?this.getTotalnumber():this.nowpage+1;
	
}
public int getstrat(){
	
	return this.number*(this.nowpage-1);
}

}
