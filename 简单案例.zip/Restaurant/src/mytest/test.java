package mytest;

import org.junit.Test;

import com.res.biz.Dishbiz;
import com.res.bizimple.Dishbizimple;
import com.res.domain.Dish;

public class test {
	@Test
public void test1(){
	Dishbiz biz=new Dishbizimple();
	//Dish s = biz.selectall();
	//System.out.println(s.getArea()+s.getDishid()+s.getDishname()+s.getPrice()+s.getVipdish());
}
	@Test
	public void test12(){
		Dishbiz biz=new Dishbizimple();
		//biz.adddish(new Dish("青龙过江","粤菜","252","22","1212"));
		System.out.println("执行");
		
	}
	@Test
	public void test132(){
		Dishbiz biz=new Dishbizimple();
		Dish selebyname = biz.selebyname("扣肉");
		System.out.println(selebyname+"125");
		
	}
	public void test3132(){
		
		Dishbiz biz=new Dishbizimple();
		 biz.delete("777");
		
		
	}
}
