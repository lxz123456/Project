package com.test19427.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.domain.Clazz;
import com.domain.Student;

public class test {
public static void main(String[] args) {
	ApplicationContext context = new ClassPathXmlApplicationContext("config-spring.xml");
	
	Student s= context.getBean("stu3",Student.class);
	Student s1=(Student) context.getBean("stu2");
	System.out.println(s1);
	System.out.println(s);
	Clazz clasz=context.getBean("clasz",Clazz.class);
	System.out.println("This a bean :"+clasz.getClassid()+clasz.getStu());
}
}
