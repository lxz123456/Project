package com.domain;

public class Student {
	private String name;
	private String userid;
private String password;
private String username;

public String getUsername() {
	return username;
}

public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public void setUsername(String username) {
	this.username = username;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getUserid() {
	return userid;
}
public void setUserid(String userid) {
	this.userid = userid;
}
public Student(String username, String password, String name, String userid) {
	super();
	this.username = username;
	this.password = password;
	this.name = name;
	this.userid = userid;
}
public Student() {
	super();
}
@Override
public String toString() {
	return "student [username=" + username + ", password=" + password + ", name=" + name + ", userid=" + userid + "]";
}

}
