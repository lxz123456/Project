package com.domain;

public class Clazz {

private String classid;
private Student stu;
public String getClassid() {
	return classid;
}
public void setClassid(String classid) {
	this.classid = classid;
}
public Student getStu() {
	return stu;
}
public void setStu(Student stu) {
	this.stu = stu;
}
public Clazz(String classid, Student stu) {
	super();
	this.classid = classid;
	this.stu = stu;
}
public Clazz() {
	super();
}
@Override
public String toString() {
	return "Clazz [classid=" + classid + ", stu=" + stu + "]";
}


}
