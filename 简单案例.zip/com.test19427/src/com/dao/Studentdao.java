package com.dao;

import java.util.List;

import com.domain.Student;

public class Studentdao {

	
	public List<Student> findall(){
		
		
		return null;
		
	}
	
}
