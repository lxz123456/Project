package test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.dao.Userdao;
import com.domain.User;

public class test {
public static void main(String[] args) throws IOException {
	InputStream instr = Resources.getResourceAsStream("config/config-mybatis.xml");
	SqlSessionFactory build = new SqlSessionFactoryBuilder().build(instr);
	SqlSession osess = build.openSession();
	Userdao userdao=osess.getMapper(Userdao.class);
	User us=new User();
	us.setUsername("123");
	us.setPassword("123");
	//List<User> use=userdao.findbyid(us);
	//List<User> use=userdao.findall();
	User use=userdao.findbyid(us);
	//System.out.println(userdao.findbyid(us));
	List<User>use2=userdao.findall();
	//System.out.println(use2);
	
	
	List<User>use32=userdao.findgander();
	
	System.out.println(use32);
	osess.close();
}
}
