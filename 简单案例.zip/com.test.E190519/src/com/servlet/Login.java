package com.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.dao.Userdao;
import com.domain.User;

/**
 * Servlet implementation class servlet
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String op=request.getParameter("op");
		if("entry".equals(op)){
			Entry(request,response);
			
		}
		
		
	}

	private void Entry(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		InputStream instr = Resources.getResourceAsStream("config/config-mybatis.xml");
		SqlSessionFactory build = new SqlSessionFactoryBuilder().build(instr);
		SqlSession osess = build.openSession();
		Userdao userdao=osess.getMapper(Userdao.class);
		User user=new User();
		
		user.setUsername(request.getParameter("account"));
		user.setPassword(request.getParameter("password"));
		
		User use=userdao.findbyid(user);
		List<User> list = userdao.findall();
		List<User> gan = userdao.findgander();
		System.out.println(use);
		System.out.println(list);
		HttpSession se=request.getSession();
		if(use!=null){
			
			se.setAttribute("use", use);
			se.setAttribute("list", list);
			se.setAttribute("gan", gan);
			request.getRequestDispatcher("/Main/Userwelcome.jsp").forward(request, response);
		}else {
		request.setAttribute("flag", "对不起 请输入正确的账号密码");
		request.getRequestDispatcher("/Entry/Entry.jsp").forward(request, response);
		
		}
		
		
		osess.close();
		
	
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
