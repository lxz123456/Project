package com.dao;

import com.domain.User;

public class Userdaoimple  {

	
	}

	
	

