package com.dao;

import java.util.List;

import com.domain.User;

public interface Userdao {
public User findbyid(User us);
public List<User> findall();
public List<User> findgander();

}
